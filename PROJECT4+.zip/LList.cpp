#include <iostream>
#include "LList.h"

//----------------------------------------------------
//	           constructor & destructor
//----------------------------------------------------
LList::LList() {
	head = NULL;
}

LList::~LList() {
	if (head != NULL) {
		delete head;
	}
}

//----------------------------------------------------
//				    print
//----------------------------------------------------
// prints each node in the list, or EMPTY when there
// are no nodes to print
//----------------------------------------------------
void LList::print() {
	if (head == NULL)
		cout << "EMPTY\n\n";
	else {
		node * p;
		p = head;
		while (p != NULL) {
			p->print();
			p = p->next;
		}
		cout << endl;
	}
} // print()

  //----------------------------------------------------
  //				         search
  //----------------------------------------------------
  // Given: key to search for
  // Returns: pointer to a node in the list found to have
  //          the given search key, or NULL for not found
  //----------------------------------------------------
node * LList::search(int srchKey) {
	node * p;
	p = head;
	while (p != NULL) {
		if (p->key == srchKey) {
			return p;
		}
		p = p->next;
	}
	return NULL;
} // search()

  //----------------------------------------------------
  //				   findNode
  //----------------------------------------------------
  // Given: a key to search for
  // Searches for a node with the given key, and if
  // found, invokes the print() method in the found node.
  // Otherwise, prints "not found"
  //----------------------------------------------------
void LList::findNode(int srchkey) {
	node * p = search(srchkey);
	if (p != NULL) {
		p->print();
	}
	else {
		cout << "not found\n";
	}
} // findNode()

  //----------------------------------------------------
  //				    getb4
  //----------------------------------------------------
  // Given: a pointer to a node in the list
  // Returns: a pointer to the node in the list BEFORE
  //               the one pointed to by r, OR
  //          NULL when r is the head or not found in
  //               the list
  //----------------------------------------------------
node * LList::getb4(node * r) {
	if (r == head || r == NULL) {
		return NULL;
	}
	else {
		node * p;
		p = head;
		while (p != NULL) {
			if (p->next == r) {
				return p;
			}
			p = p->next;
		}
	}
	return NULL;

} // getb4()

  //----------------------------------------------------
  //				       insert
  //----------------------------------------------------
  // Given: key and data for a new node
  // Allocates/populates a new node
  // When a node with the same key already exists:
  //     the current/old node is replaced by the new one
  //     and the old one is placed on the new one's
  //     duplicate list.
  // Otherwise, the new node is prepended to the head
  //     of the list.
  //----------------------------------------------------
void LList::insert(int k, string d) {
	node * p = new node(k, d);
	node * r = search(k);
	if (head == NULL) {
		head = p;
	}
	else if (r == NULL) {
		p->next = head;
		head = p;
	}
	else if (r == head) {
		p->dup = head;
		p->next = head->next;
		head->next = NULL;
		head = p;
	}
	else {
		p->dup = r;
		getb4(r)->next = p;
		p->next = r->next;
		r->next = NULL;
	}

} // insert()

  //----------------------------------------------------
  //				       remove
  //----------------------------------------------------
  // Given: a pointer to a node in the list to be removed
  //        BUT NOT DELETED/DESTROYED
  // Returns: TRUE - when the node was successfully removed
  //          FALSE - when the given node is NULL or the node
  //                  is not actually in the list.
  // Simply removes the node from the linked list.
  // (including setting the NEXT pointer in the node to NULL)
  //----------------------------------------------------
bool LList::remove(node * r) {
	if (r == NULL || search(r->key) == NULL) {
		return false;
	}
	else if (r == head && head->next == NULL) {
		head = NULL;
	}
	else if (r == head) {
		r = head->next;
		head->next = NULL;
		head = r;
	}
	else {
		getb4(r)->next = r->next;
		r->next = NULL;
	}
	return true;
} // remove()

  //----------------------------------------------------
  //				       drop
  //----------------------------------------------------
  // Given: key of a node to drop
  // Returns: TRUE when a node was found and deleted
  //          FALSE when a node with the given key not found,
  //                or the remove() fails.
  // Searches for a node in the list with the given key:
  // When found, removes and deletes the node
  //----------------------------------------------------
bool LList::drop(int k) {
	node * p = search(k);
	if (remove(p)) {
		delete p;
		return true;
	}
	else {
		return false;
	}

} // drop()

  //----------------------------------------------------
  //				        max
  //----------------------------------------------------
  // Returns: a pointer to the node with the highest key
  //          or NULL when there list is empty.
node * LList::max() {
	if (head == NULL) {
		return NULL;
	}
	else {
		int max = head->key;
		node * p;
		p = head->next;
		while (p != NULL) {
			if (p->key > max) {
				max = p->key;
			}
			p = p->next;
		}
		return search(max);
	}
} // max()

  //----------------------------------------------------
  //				       sort
  //----------------------------------------------------
  // Sorts the list in ascending order by key values
void LList::sort() {
	LList * temp = new LList();
	while (head != NULL) {
		node * currentMax = max();
		remove(currentMax);
		currentMax->next = temp->head;
		temp->head = currentMax;
	}
	head = temp->head;
} // sort()